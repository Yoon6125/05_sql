package com.javasqlpostset.java;

import java.sql.SQLException;

import com.javasqldata.java.DatabaseConnect;

public class ContentReply {
	public void run(int num) {
		DatabaseConnect.dbInit();
		String a = String.format("select b_id,b_reply_text,b_datetime from board3 where b_reply_ori=%d;", num);
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(a);
			while (DatabaseConnect.result.next()) {
				String b = DatabaseConnect.result.getString("b_id");
				String c = DatabaseConnect.result.getString("b_reply_text");
				String d = DatabaseConnect.result.getString("b_datetime");
				String reply = String.format("%s : %s   %s", b, c, d);

				System.out.println(reply);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
