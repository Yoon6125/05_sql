package com.javasqlpostset.java;

import java.sql.SQLException;
import java.util.Scanner;

import com.javasqldata.java.DatabaseConnect;

public class ReadPostContent {
	Scanner sc = new Scanner(System.in);
	ContentReply cr = new ContentReply();
	ReplyWrite rw = new ReplyWrite();

	public void run() {
		DatabaseConnect.dbInit();
		System.out.println("읽을 글 번호를 선택: ");
		String readnum = sc.nextLine();
		int a = Integer.parseInt(readnum);
		String x = String.format("select b_text from board3 where b_no=%d;", a);
		try {
			DatabaseConnect.result = DatabaseConnect.st.executeQuery(x);
			while (DatabaseConnect.result.next()) {
				String con = DatabaseConnect.result.getString("b_text");
				System.out.println(con);

				System.out.println("-----------댓글----------");
				cr.run(a);

				System.out.println("댓글 쓰기 :1     나가기: 2");
				String replywrite = sc.nextLine();
				switch (replywrite) {
				case "1":
					rw.run(a);
					break;
				case "2":
					break;
				default:
					break;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
