package com.javasqlpostset.java;

import java.util.Scanner;

import com.javasqldata.java.DatabaseConnect;

public class WritePost {
	Scanner sc = new Scanner(System.in);

	public void run() {
		DatabaseConnect.dbInit();
		System.out.println("글 제목 입력:");
		String title = sc.nextLine();
		System.out.println("글 내용 입력:");
		String content = sc.nextLine();
		System.out.println("글쓴이 입력:");
		String writer = sc.nextLine();

		String x = String.format("insert into board3 (b_title ,b_id,b_text ,b_datetime) values('%s','%s','%s',now());",
				title, writer, content);
		DatabaseConnect.dbExecuteUpdate(x);
	}
}
