package com.sqlboard.java;

public class Main {

	public static void main(String[] args) {
		ProcBoard pb = new ProcBoard();

		pb.run();
	}

}
