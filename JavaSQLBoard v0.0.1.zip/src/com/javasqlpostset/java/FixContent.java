package com.javasqlpostset.java;

import java.util.Scanner;

import com.javasqldata.java.DatabaseConnect;

public class FixContent {
	Scanner sc = new Scanner(System.in);

	public void run() {
		DatabaseConnect.dbInit();
		System.out.println("수정할 글 번호를 입력하세요: ");
		String fixnum = sc.nextLine();
		int x = Integer.parseInt(fixnum);

		System.out.println("수정할 내용으로 입력하세요: ");
		String fixcont = sc.nextLine();

		String a = String.format("update board3 set b_text='%s'where b_no= %d; ", fixcont, x);
		DatabaseConnect.dbExecuteUpdate(a);
	}
}
