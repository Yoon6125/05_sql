package com.javasqlpostset.java;

import java.util.Scanner;

import com.javasqldata.java.DatabaseConnect;

public class ReplyWrite {
	Scanner sc = new Scanner(System.in);

	public void run(int num) {
		DatabaseConnect.dbInit();
		System.out.println("작성자 명을 입력해주세요: ");
		String name = sc.nextLine();
		System.out.println("작성할 댓글을 입력해주세요:");
		String reply = sc.nextLine();

		String a = String.format(
				"insert into board3 (b_id,b_datetime,b_reply_ori,b_reply_text)" + "values ('%s',now(),%d,'%s');", name,
				num, reply);
		DatabaseConnect.dbExecuteUpdate(a);

	}
}
