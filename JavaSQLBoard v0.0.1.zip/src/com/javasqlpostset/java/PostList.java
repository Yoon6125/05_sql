package com.javasqlpostset.java;

import java.util.Scanner;

import com.javasqldata.java.DatabaseConnect;

public class PostList {
	final int POST_INDEX = 4;

	Scanner sc = new Scanner(System.in);

	public void run() {
		int currentindex = 0;
		int readindex = 1;
		DatabaseConnect.dbInit();

		String s = null;
		loop_xx: while (true) {
			currentindex = (readindex - 1) * POST_INDEX;
			s = String.format("select * from board3 limit %d,%d;", currentindex, POST_INDEX);
			DatabaseConnect.dbExecuteQuery(s);
			System.out.println("페이지 넘기기:1    , 이전페이지:2  , 종료:x ");
			String readpage = sc.nextLine();
			switch (readpage) {
			case "1":
				readindex = readindex + 1;
				break;
			case "2":
				readindex = readindex - 1;
				break;
			case "x":
				System.out.println("종료");
				break loop_xx;
			default:
				break;
			}

		}

	}

}
