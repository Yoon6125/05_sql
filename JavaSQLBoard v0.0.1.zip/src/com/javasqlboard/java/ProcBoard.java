package com.javasqlboard.java;

import java.util.Scanner;

import com.javasqlpostset.java.DeletePost;
import com.javasqlpostset.java.FixContent;
import com.javasqlpostset.java.PostList;
import com.javasqlpostset.java.ReadPostContent;
import com.javasqlpostset.java.WritePost;

public class ProcBoard {

	Scanner sc = new Scanner(System.in);
	WritePost wp = new WritePost();
	PostList pl = new PostList();
	ReadPostContent rpc = new ReadPostContent();
	DeletePost dp = new DeletePost();
	FixContent fc = new FixContent();

	void run() {

		System.out.println("------------------------------------------------------------------------------------");
		System.out.println("--------------------계시판 연습 v.0.0--------------------------------------------------");
		System.out.println("------------------------------------------------------------------------------------");
		loop_xx: while (true) {
			System.out.println("1.글 목록  / 2. 글 읽기 / 3. 글 쓰기 / 4. 글 삭제  / 5. 글 수정 / 0. 관리자 페이지 / e. 종료");
			String choose = sc.nextLine();
			switch (choose) {
			case "1":
				pl.run();
				break;
			case "2":
				rpc.run();
				break;
			case "3":
				wp.run();
				break;
			case "4":
				dp.run();
				break;
			case "5":
				fc.run();
				break;

			case "0":
				break;
			case "e":
				break loop_xx;
			default:
				break;
			}
		}

	}

}
