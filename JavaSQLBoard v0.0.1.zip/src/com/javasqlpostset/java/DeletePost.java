package com.javasqlpostset.java;

import java.util.Scanner;

import com.javasqldata.java.DatabaseConnect;

public class DeletePost {
	Scanner sc = new Scanner(System.in);

	public void run() {
		DatabaseConnect.dbInit();

		System.out.println("삭제할 글 번호 선택: ");
		String deletenum = sc.nextLine();

		int x = Integer.parseInt(deletenum);

		String b = String.format("delete from board3 where b_no= %d;", x);
		DatabaseConnect.dbExecuteUpdate(b);

	}
}
